import { create } from 'zustand';
import type { User } from '../types';
import { authService } from '../services/authService';

interface AuthState {
    user: User | null;
    isLoading: boolean;
    error: string | null;

    initialize: () => void;
    login: (email: string) => Promise<void>;
    logout: () => void;
    updateProfile: (updates: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
    user: null,
    isLoading: true,
    error: null,

    initialize: () => {
        const user = authService.getCurrentUser();
        set({ user, isLoading: false });
    },

    login: async (email: string) => {
        set({ isLoading: true, error: null });
        try {
            const user = await authService.login(email);
            set({ user, isLoading: false });
        } catch (err) {
            set({ error: (err as Error).message, isLoading: false });
        }
    },

    logout: () => {
        authService.logout();
        set({ user: null });
    },

    updateProfile: (updates: Partial<User>) => {
        try {
            const user = authService.updateProfile(updates);
            set({ user });
        } catch (err) {
            set({ error: (err as Error).message });
        }
    }
}));
