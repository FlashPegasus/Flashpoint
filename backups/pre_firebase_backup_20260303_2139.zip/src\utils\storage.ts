export interface StorageAdapter {
    get<T>(key: string, defaultValue: T): T;
    set<T>(key: string, value: T): void;
    remove(key: string): void;
    clear(): void;
}

export const localStorageAdapter: StorageAdapter = {
    get: <T>(key: string, defaultValue: T): T => {
        try {
            const item = localStorage.getItem(`flashpoint_${key}`);
            return item ? (JSON.parse(item) as T) : defaultValue;
        } catch (error) {
            console.error(`Error reading from storage key "${key}":`, error);
            return defaultValue;
        }
    },

    set: <T>(key: string, value: T): void => {
        try {
            localStorage.setItem(`flashpoint_${key}`, JSON.stringify(value));
        } catch (error) {
            console.error(`Error writing to storage key "${key}":`, error);
        }
    },

    remove: (key: string): void => {
        localStorage.removeItem(`flashpoint_${key}`);
    },

    clear: (): void => {
        Object.keys(localStorage)
            .filter(key => key.startsWith('flashpoint_'))
            .forEach(key => localStorage.removeItem(key));
    }
};

// Default setup using local storage, but ready to be swapped
export const storage = localStorageAdapter;
