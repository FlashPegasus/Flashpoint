import { Link } from 'react-router-dom';
import { Trophy, Zap, Shield, BarChart3, Users, PlusCircle } from 'lucide-react';
import PageShell from '../components/layout/PageShell';
import { Button, Card } from '../components/ui';

const Home: React.FC = () => {
    return (
        <PageShell>
            {/* Hero Section */}
            <section className="section py-32 overflow-hidden flex items-center min-h-[85vh]">
                <div className="container relative z-10">
                    <div className="flex flex-col items-center text-center">
                        <div className="p-4 mb-8 glass rounded-2xl shadow-glow">
                            <Zap size={32} className="text-purple fill-purple/30" />
                        </div>
                        <h1 className="mb-8 max-w-4xl">
                            Manage TCG Tournaments Like a <span className="text-mana-purple">Pro</span>
                        </h1>
                        <p className="text-xl text-secondary mb-12 max-w-2xl mx-auto leading-relaxed">
                            From local game nights to high-stakes leagues. FlashPoint is the faster, smarter way to run 1v1 and multiplayer TCG events.
                        </p>
                        <div className="flex gap-6 flex-wrap justify-center">
                            <Button size="lg" variant="glow" onClick={() => (window.location.href = '/tournament/create')}>
                                Create Tournament
                            </Button>
                            <Button size="lg" variant="secondary" onClick={() => (window.location.href = '/discover')}>
                                Browse Events
                            </Button>
                        </div>
                    </div>
                </div>
            </section>

            {/* Features Grid */}
            <section className="section py-32 bg-white/[0.01]">
                <div className="container">
                    <div className="text-center mb-24">
                        <h2 className="mb-6">Everything You Need</h2>
                        <p className="text-secondary max-w-2xl mx-auto">Powerful features designed specifically for the modern TCG community.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                        {[
                            { icon: <Users size={28} />, title: 'Multiplayer Buff', desc: 'Native support for Commander and other multiplayer formats with smart table grouping.' },
                            { icon: <Trophy size={28} />, title: 'League Ready', desc: 'Link multiple tournaments into a season-long league with automated standings.' },
                            { icon: <Zap size={28} />, title: 'Fast Pairings', desc: 'Instant Swiss and multiplayer pairings that respect player points and previous matchups.' },
                            { icon: <Shield size={28} />, title: 'Robust & Reliable', desc: 'Handles late entries, drops, and score corrections with ease at any stage.' },
                            { icon: <BarChart3 size={28} />, title: 'Deep Analytics', desc: 'Track metagame trends, player win rates, and tournament growth over time.' },
                            { icon: <PlusCircle size={28} />, title: 'PWA Power', desc: 'Install it on your phone like a native app. Works offline and is lighting fast.' }
                        ].map((feature, i) => (
                            <Card key={i} className="hover-lift p-10">
                                <div className="mb-6 text-mana-purple">{feature.icon}</div>
                                <h3 className="mb-4">{feature.title}</h3>
                                <p className="text-secondary leading-relaxed">{feature.desc}</p>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>
        </PageShell >
    );
};

export default Home;
