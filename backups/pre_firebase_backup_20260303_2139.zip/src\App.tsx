import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './stores/authStore';

// Pages
import Home from './pages/Home';
import Login from './pages/Login';
import TournamentCreate from './pages/TournamentCreate';
import TournamentDashboard from './pages/TournamentDashboard';
import MyArea from './pages/MyArea';
import Discover from './pages/Discover';
import TournamentPublic from './pages/TournamentPublic';
import Leagues from './pages/Leagues';
import Profile from './pages/Profile';



const App: React.FC = () => {
  const { initialize, user } = useAuthStore();

  useEffect(() => {
    initialize();
  }, [initialize]);

  const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
    if (!user) return <Navigate to="/login" />;
    return <>{children}</>;
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />

        {/* Protected Routes */}
        <Route path="/my-area" element={<ProtectedRoute><MyArea /></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
        <Route path="/tournament/create" element={<ProtectedRoute><TournamentCreate /></ProtectedRoute>} />
        <Route path="/tournament/:id" element={<ProtectedRoute><TournamentDashboard /></ProtectedRoute>} />

        {/* Public Routes */}
        <Route path="/discover" element={<Discover />} />
        <Route path="/leagues" element={<Leagues />} />
        <Route path="/tournament/:id/public" element={<TournamentPublic />} />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
};

export default App;
