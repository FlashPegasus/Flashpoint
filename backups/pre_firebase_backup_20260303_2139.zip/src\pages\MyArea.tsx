import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trophy, Plus, Users, Calendar, ArrowRight } from 'lucide-react';
import PageShell from '../components/layout/PageShell';
import { Card, Button } from '../components/ui';
import { useAuthStore } from '../stores/authStore';
import { useTournamentStore } from '../stores/tournamentStore';

const MyArea: React.FC = () => {
    const { user } = useAuthStore();
    const { tournaments, loadTournaments } = useTournamentStore();
    const navigate = useNavigate();

    React.useEffect(() => {
        loadTournaments();
    }, [loadTournaments]);

    const myTournaments = tournaments.filter(t => t.organizerId === user?.id);
    const participatingTournaments = tournaments.filter(t => t.participants.some(p => p.playerId === user?.id));

    return (
        <PageShell>
            <div className="container py-8 animate-fade-in">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-outfit mb-1">My Dashboard</h1>
                        <p className="text-secondary">Welcome back, {user?.name}!</p>
                    </div>
                    <Button variant="glow" onClick={() => navigate('/tournament/create')}>
                        <Plus size={18} className="mr-2" /> New Tournament
                    </Button>
                </div>

                {/* Stats Strip */}
                <div className="grid grid-cols-4 gap-4 mb-10">
                    {[
                        { label: 'Tournaments Run', value: myTournaments.length, icon: <Trophy size={16} /> },
                        { label: 'Events Joined', value: participatingTournaments.length, icon: <Users size={16} /> },
                        { label: 'Win Rate', value: '64%', icon: <ArrowRight size={16} /> },
                        { label: 'Rank', value: '#12', icon: <Trophy size={16} /> }
                    ].map((stat, i) => (
                        <div key={i} className="glass p-4 rounded-2xl border-white/5">
                            <div className="text-xs text-muted flex items-center gap-1 mb-1">
                                {stat.icon} {stat.label}
                            </div>
                            <div className="text-2xl font-bold font-outfit">{stat.value}</div>
                        </div>
                    ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Managing Section */}
                    <div>
                        <h2 className="text-2xl font-outfit mb-4 flex items-center gap-2">
                            <Shield size={20} className="text-purple" style={{ color: 'var(--color-purple)' }} /> Managing
                        </h2>
                        <div className="flex flex-col gap-4">
                            {myTournaments.length === 0 ? (
                                <Card className="text-center py-10 opacity-60">
                                    <p className="text-muted mb-4">You aren't managing any tournaments yet.</p>
                                    <Button variant="secondary" size="sm" onClick={() => navigate('/tournament/create')}>Create your first one</Button>
                                </Card>
                            ) : (
                                myTournaments.map(t => (
                                    <Link key={t.id} to={`/tournament/${t.id}`}>
                                        <div className="glass-card p-5 hover:border-purple/50 transition-all group">
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <h3 className="text-lg font-bold group-hover:text-purple transition-colors">{t.name}</h3>
                                                    <p className="text-xs text-secondary mt-1 flex items-center gap-1">
                                                        <Calendar size={12} /> {t.date} • {t.participants.length} Players
                                                    </p>
                                                </div>
                                                <span className={`text-[10px] uppercase font-bold px-2 py-1 rounded-full ${t.status === 'registration' ? 'bg-purple/10 text-purple' : 'bg-green/10 text-green'}`}>
                                                    {t.status}
                                                </span>
                                            </div>
                                        </div>
                                    </Link>
                                ))
                            )}
                        </div>
                    </div>

                    {/* Participating Section */}
                    <div>
                        <h2 className="text-2xl font-outfit mb-4 flex items-center gap-2">
                            <Users size={20} className="text-blue" style={{ color: 'var(--color-blue)' }} /> Playing In
                        </h2>
                        <div className="flex flex-col gap-4">
                            {participatingTournaments.length === 0 ? (
                                <Card className="text-center py-10 opacity-60">
                                    <p className="text-muted mb-4">You aren't signed up for any tournaments.</p>
                                    <Button variant="secondary" size="sm" onClick={() => navigate('/discover')}>Discover Events</Button>
                                </Card>
                            ) : (
                                participatingTournaments.map(t => (
                                    <Link key={t.id} to={`/tournament/${t.id}/public`}>
                                        <div className="glass-card p-5 hover:border-blue/50 transition-all group">
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <h3 className="text-lg font-bold group-hover:text-blue transition-colors">{t.name}</h3>
                                                    <p className="text-xs text-secondary mt-1">{t.format} • {t.location}</p>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-xs text-muted">Your Rank</p>
                                                    <p className="text-lg font-bold font-outfit">#{t.participants.find(p => p.playerId === user?.id)?.rank || '-'}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </Link>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </PageShell>
    );
};

// Internal Shield icon mockup since lucide export might be different
const Shield: React.FC<{ size: number, className: string, style?: any }> = ({ size, className, style }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} style={style}>
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
);

export default MyArea;
