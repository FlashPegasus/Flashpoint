export type UserRole = 'organizer' | 'player' | 'admin';

export interface User {
    id: string;
    name: string;
    email: string;
    role: UserRole;
    avatar?: string;
    bio?: string;
    stats: {
        tournamentsPlayed: number;
        wins: number;
        draws: number;
        losses: number;
        leaguesJoined: number;
        accumulatedPoints: number;
    };
}

export type TournamentFormat = '1v1' | 'multiplayer';
export type TournamentStatus = 'draft' | 'registration' | 'ongoing' | 'completed' | 'cancelled';

export interface ScoringPosition {
    position: number;
    points: number;
}

export interface ScoringConfig {
    type: 'standard' | 'positional' | 'custom';
    pointsPerWin?: number;
    pointsPerDraw?: number;
    pointsPerLoss?: number;
    positions?: Record<number, Record<number, number>>; // tableSize -> (position -> points)
}

export interface Participant {
    playerId: string;
    name: string;
    avatar?: string;
    status: 'active' | 'withdrawn' | 'late';
    joinedRound: number;
    deckName?: string;
    totalPoints: number;
    rank?: number;
    // Tie-breakers
    buchholz?: number;
    owp?: number;
    previousOpponents?: string[]; // Array of playerIds
}

export interface TableResult {
    playerId: string;
    position: number;
    points: number;
}

export interface Table {
    id: string;
    playerIds: string[];
    results: TableResult[];
    status: 'pending' | 'completed';
}

export interface Round {
    number: number;
    tables: Table[];
    status: 'pending' | 'completed';
}

export interface Tournament {
    id: string;
    name: string;
    date: string;
    location: string;
    description: string;
    format: TournamentFormat;
    pairingMode: 'standard' | 'fair';
    status: TournamentStatus;
    organizerId: string;

    // Configuration
    minPlayersPerTable: number;
    maxPlayersPerTable: number;
    exactTableSize?: number;
    scoring: ScoringConfig;

    // Policies
    allowLateRegistration: boolean;
    allowWithdrawal: boolean;
    maxParticipants?: number;

    // Data
    participants: Participant[];
    rounds: Round[];
    leagueId?: string;
}

export type LeagueScoringType = 'sum' | 'best_x_of_y' | 'weighted';

export interface LeagueStanding {
    playerId: string;
    playerName: string;
    totalPoints: number;
    tournamentsPlayed: number;
    rank: number;
}

export interface League {
    id: string;
    name: string;
    description: string;
    organizerId: string;
    startDate: string;
    endDate: string;
    status: 'active' | 'completed';
    scoringType: LeagueScoringType;
    scoringParams?: {
        bestX?: number;
        weights?: Record<string, number>; // tournamentId -> weight
    };
    tournamentIds: string[];
    memberIds: string[];
    standings: LeagueStanding[];
}
