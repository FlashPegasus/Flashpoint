import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, ArrowRight } from 'lucide-react';
import { useAuthStore } from '../stores/authStore';
import PageShell from '../components/layout/PageShell';
import { Input } from '../components/ui';

const Login: React.FC = () => {
    const [email, setEmail] = React.useState('');
    const { login, isLoading, error } = useAuthStore();
    const navigate = useNavigate();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (email) {
            await login(email);
            navigate('/my-area');
        }
    };

    return (
        <PageShell>
            <div className="container section flex justify-center">
                <div className="glass-card p-10 w-full max-w-md animate-fade-in">
                    <div className="text-center mb-10">
                        <h2 className="text-3xl mb-2">Welcome Back</h2>
                        <p className="text-secondary">Sign in to manage your tournaments</p>
                    </div>

                    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
                        <div className="relative">
                            <Input
                                label="Email Address"
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="name@example.com"
                                required
                            />
                            <Mail className="absolute right-4 bottom-3 text-muted" size={18} />
                        </div>

                        {error && <p className="text-red-500 text-sm text-center">{error}</p>}

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:shadow-glow transition-all"
                            style={{ backgroundColor: 'var(--color-purple)', color: 'white', opacity: isLoading ? 0.7 : 1 }}
                        >
                            {isLoading ? 'Signing In...' : 'Continue'}
                            {!isLoading && <ArrowRight size={18} />}
                        </button>
                    </form>

                    <div className="mt-10">
                        <div className="flex items-center gap-4 mb-8">
                            <div style={{ flex: 1, height: '1px', backgroundColor: 'var(--border-glass)' }}></div>
                            <span className="text-xs text-muted uppercase tracking-widest">Or social login</span>
                            <div style={{ flex: 1, height: '1px', backgroundColor: 'var(--border-glass)' }}></div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <button className="glass py-3 flex items-center justify-center gap-2 hover:bg-glass transition-all">
                                <img src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg" width="16" alt="Google" />
                                <span className="text-sm font-medium">Google</span>
                            </button>
                            <button className="glass py-3 flex items-center justify-center gap-2 hover:bg-glass transition-all">
                                <img src="https://upload.wikimedia.org/wikipedia/icons/discord.svg" width="16" alt="Discord" onError={(e) => (e.currentTarget.src = "https://cdn.worldvectorlogo.com/logos/discord-6.svg")} />
                                <span className="text-sm font-medium">Discord</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <style>{`
        input:focus { border: 1px solid var(--color-purple) !important; }
      `}</style>
        </PageShell>
    );
};

export default Login;
