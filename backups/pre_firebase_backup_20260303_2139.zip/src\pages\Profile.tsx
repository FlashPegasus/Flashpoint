import React, { useMemo } from 'react';
import { useAuthStore } from '../stores/authStore';
import { tournamentService } from '../services/tournamentService';
import { firebaseExportService } from '../services/firebaseExportService';
import PageShell from '../components/layout/PageShell';
import { Trophy, Star, Target, Calendar, User as UserIcon, LogOut, Download } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Profile: React.FC = () => {
    const { user, logout } = useAuthStore();
    const navigate = useNavigate();

    const stats = useMemo(() => {
        if (!user) return null;
        return tournamentService.getUserStats(user.id);
    }, [user]);

    if (!user || !stats) return null;

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <PageShell title="My Profile">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-12">
                {/* User Info Card */}
                <div className="lg:col-span-1">
                    <div className="glass card p-6 text-center animate-fade-in">
                        <div className="w-24 h-24 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-accent/30 shadow-lg">
                            {user.avatar ? (
                                <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover" />
                            ) : (
                                <UserIcon size={40} className="text-accent" />
                            )}
                        </div>
                        <h2 className="text-2xl font-bold mb-1">{user.name}</h2>
                        <p className="text-secondary mb-6">{user.email}</p>

                        <div className="px-4 py-2 bg-accent/10 rounded-full text-accent text-sm font-medium inline-block mb-6 border border-accent/20">
                            {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                        </div>

                        <button
                            onClick={() => firebaseExportService.exportData()}
                            className="flex items-center justify-center gap-2 w-full p-3 rounded-xl border border-accent/30 text-accent hover:bg-accent/10 transition-colors mb-4"
                        >
                            <Download size={18} />
                            Export Data for Firebase
                        </button>

                        <button
                            onClick={handleLogout}
                            className="flex items-center justify-center gap-2 w-full p-3 rounded-xl border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-colors"
                        >
                            <LogOut size={18} />
                            Logout Session
                        </button>
                    </div>
                </div>

                {/* Statistics & History */}
                <div className="lg:col-span-2 space-y-8">
                    {/* Stats Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 animate-slide-up">
                        <StatCard
                            icon={<Trophy size={20} className="text-yellow-400" />}
                            label="Total Wins"
                            value={stats.wins}
                        />
                        <StatCard
                            icon={<Star size={20} className="text-accent" />}
                            label="Top 3"
                            value={stats.top3}
                        />
                        <StatCard
                            icon={<Target size={20} className="text-blue-400" />}
                            label="Total Points"
                            value={stats.totalPoints}
                        />
                        <StatCard
                            icon={<Calendar size={20} className="text-purple-400" />}
                            label="Tournaments"
                            value={stats.totalTournaments}
                        />
                    </div>

                    {/* Recent Tournaments */}
                    <div className="glass p-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                            <Calendar size={20} className="text-accent" />
                            Recent Participation
                        </h3>
                        {stats.recentTournaments.length > 0 ? (
                            <div className="space-y-4">
                                {stats.recentTournaments.map(t => (
                                    <div
                                        key={t.id}
                                        onClick={() => navigate(`/tournament/${t.id}${t.status === 'completed' ? '/public' : ''}`)}
                                        className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:border-accent/40 hover:bg-white/10 transition-all cursor-pointer group"
                                    >
                                        <div>
                                            <h4 className="font-semibold group-hover:text-accent transition-colors">{t.name}</h4>
                                            <p className="text-xs text-secondary">{new Date(t.date).toLocaleDateString()}</p>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-sm font-bold">
                                                {t.rank ? `Rank #${t.rank}` : 'No Rank'}
                                            </div>
                                            <div className="text-xs text-secondary">
                                                {t.points} Points
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-10 text-secondary">
                                <p>You haven't participated in any tournaments yet.</p>
                                <button
                                    onClick={() => navigate('/discover')}
                                    className="text-accent hover:underline mt-2"
                                >
                                    Browse active tournaments
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </PageShell>
    );
};

const StatCard: React.FC<{ icon: React.ReactNode, label: string, value: number | string }> = ({ icon, label, value }) => (
    <div className="glass p-4 text-center">
        <div className="bg-white/5 w-10 h-10 rounded-lg flex items-center justify-center mx-auto mb-2 border border-white/10">
            {icon}
        </div>
        <div className="text-2xl font-bold">{value}</div>
        <div className="text-[10px] uppercase tracking-wider text-secondary font-medium">{label}</div>
    </div>
);

export default Profile;
