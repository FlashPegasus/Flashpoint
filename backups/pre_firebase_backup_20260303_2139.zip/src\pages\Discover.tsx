import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Filter, Calendar, Users as UsersIcon, Trophy } from 'lucide-react';
import PageShell from '../components/layout/PageShell';
import { Card, Input, Button } from '../components/ui';
import { useTournamentStore } from '../stores/tournamentStore';

const Discover: React.FC = () => {
    const { tournaments, loadTournaments } = useTournamentStore();
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = React.useState('');

    React.useEffect(() => {
        loadTournaments();
    }, [loadTournaments]);

    const filtered = tournaments.filter(t =>
        t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.format.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <PageShell>
            <div className="container py-8 animate-fade-in">
                <div className="mb-10">
                    <h1 className="text-4xl font-outfit mb-4">Discover Events</h1>
                    <div className="flex gap-4 flex-wrap">
                        <div className="relative flex-grow max-w-md">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-primary opacity-60" size={18} />
                            <Input
                                placeholder="Search by name, format, or store..."
                                className="pl-10"
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <Button variant="secondary">
                            <Filter size={18} className="mr-2" /> Filters
                        </Button>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filtered.length === 0 ? (
                        <div className="col-span-full py-20 text-center glass rounded-3xl">
                            <Search size={48} className="mx-auto mb-4 text-muted opacity-20" />
                            <h3 className="text-xl text-secondary">No tournaments found matching your search.</h3>
                        </div>
                    ) : (
                        filtered.map(t => (
                            <Card key={t.id} className="group hover:border-purple/30 transition-all cursor-pointer" onClick={() => navigate(`/tournament/${t.id}/public`)}>
                                <div className="flex justify-between items-start mb-4">
                                    <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${t.format === 'multiplayer' ? 'bg-purple/10 text-purple' : 'bg-blue/10 text-blue'}`} style={{ color: t.format === 'multiplayer' ? 'var(--color-purple)' : 'var(--color-blue)' }}>
                                        {t.format}
                                    </div>
                                    <span className="text-xs text-muted">{t.status}</span>
                                </div>
                                <h3 className="text-xl font-bold mb-2 group-hover:text-purple transition-colors">{t.name}</h3>
                                <div className="flex flex-col gap-2 text-sm text-secondary mb-6">
                                    <div className="flex items-center gap-2"><Calendar size={14} /> {t.date}</div>
                                    <div className="flex items-center gap-2"><Trophy size={14} /> {t.location}</div>
                                    <div className="flex items-center gap-2"><UsersIcon size={14} /> {t.participants.length} Players</div>
                                </div>
                                <Button variant="primary" className="w-full">Join Tournament</Button>
                            </Card>
                        ))
                    )}
                </div>
            </div>
        </PageShell>
    );
};

export default Discover;
