import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Play, CheckCircle2, Trophy, Plus, UserMinus, ChevronRight, Edit3 } from 'lucide-react';
import PageShell from '../components/layout/PageShell';
import { Button, Card, Input, Modal } from '../components/ui';
import { useTournamentStore } from '../stores/tournamentStore';
import { useAuthStore } from '../stores/authStore';

const TournamentDashboard: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const { user } = useAuthStore();
    const { activeTournament, loadTournament, addParticipant, generateRound, submitResult, withdrawParticipant, completeTournament } = useTournamentStore();
    const [activeTab, setActiveTab] = useState<'participants' | 'rounds' | 'standings' | 'settings'>('participants');
    const [newPlayerName, setNewPlayerName] = useState('');

    // Modal State
    const [selectedTable, setSelectedTable] = useState<{ round: number, table: any } | null>(null);
    const [tempResults, setTempResults] = useState<Record<string, number>>({});

    useEffect(() => {
        if (id) loadTournament(id);
    }, [id, loadTournament]);

    if (!activeTournament) return <PageShell><div className="container section">Tournament not found</div></PageShell>;

    const isOrganizer = activeTournament.organizerId === user?.id;

    const handleAddPlayer = () => {
        if (newPlayerName.trim() && id) {
            addParticipant(id, { name: newPlayerName.trim() });
            setNewPlayerName('');
        }
    };

    const handleOpenResultModal = (roundNum: number, table: any) => {
        setSelectedTable({ round: roundNum, table });
        const initialResults: Record<string, number> = {};
        table.playerIds.forEach((pid: string) => {
            initialResults[pid] = 1; // Default position 1
        });
        setTempResults(initialResults);
    };

    const handleSubmitTableResults = () => {
        if (!id || !selectedTable) return;

        const results = selectedTable.table.playerIds.map((pid: string) => {
            const pos = tempResults[pid] || 1;
            let pts = (selectedTable.table.playerIds.length + 1) - pos;
            if (activeTournament.format === '1v1') pts = pos === 1 ? 3 : 0;
            return { playerId: pid, position: pos, points: pts };
        });

        submitResult(id, selectedTable.round, selectedTable.table.id, results);
        setSelectedTable(null);
    };

    return (
        <PageShell>
            <div className="container py-8">
                {/* Header */}
                <div className="flex justify-between items-end mb-8 flex-wrap gap-4">
                    <div>
                        <div className="flex items-center gap-2 mb-2 text-sm font-bold uppercase tracking-wider text-purple" style={{ color: 'var(--color-purple)' }}>
                            <Trophy size={14} /> {activeTournament.format} Tournament
                        </div>
                        <h1 className="text-4xl font-outfit">{activeTournament.name}</h1>
                        <p className="text-secondary">{activeTournament.date} • {activeTournament.location}</p>
                    </div>
                    <div className="flex gap-2">
                        {isOrganizer && activeTournament.status === 'registration' && (
                            <Button variant="glow" onClick={() => id && generateRound(id)}>
                                <Play size={18} className="mr-2" /> Start First Round
                            </Button>
                        )}
                        {isOrganizer && activeTournament.status === 'ongoing' && activeTournament.rounds.every(r => r.status === 'completed') && (
                            <Button variant="danger" onClick={() => id && completeTournament(id)}>
                                <CheckCircle2 size={18} className="mr-2" /> Complete Tournament
                            </Button>
                        )}
                        <Button variant="secondary" onClick={() => navigate(`/tournament/${id}/public`)}>View Public Page</Button>
                    </div>
                </div>

                {/* Tabs Navigation */}
                <div className="flex gap-1 p-1 glass rounded-2xl mb-8 w-max">
                    {(['participants', 'rounds', 'standings', 'settings'] as const).map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`px-6 py-2 rounded-xl font-bold transition-all ${activeTab === tab ? 'bg-purple text-white shadow-lg' : 'text-secondary hover:text-primary'}`}
                            style={activeTab === tab ? { backgroundColor: 'var(--color-purple)' } : {}}
                        >
                            {tab.charAt(0).toUpperCase() + tab.slice(1)}
                        </button>
                    ))}
                </div>

                {/* Tab Content */}
                <div className="animate-fade-in">
                    {activeTab === 'participants' && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                            <div className="md:col-span-2 flex flex-col gap-4">
                                <Card title={`Participants (${activeTournament.participants.length})`}>
                                    <div className="flex flex-col gap-2">
                                        {activeTournament.participants.length === 0 ? (
                                            <p className="text-center py-8 text-muted">No players joined yet.</p>
                                        ) : (
                                            <div className="flex flex-col gap-1">
                                                {activeTournament.participants.map(p => (
                                                    <div key={p.playerId} className="flex justify-between items-center p-3 glass rounded-xl">
                                                        <div className="flex items-center gap-3">
                                                            <div className="w-8 h-8 rounded-full bg-glass flex items-center justify-center font-bold text-xs">
                                                                {p.name.charAt(0)}
                                                            </div>
                                                            <div>
                                                                <span className={p.status === 'withdrawn' ? 'text-muted line-through' : ''}>{p.name}</span>
                                                                {p.status === 'withdrawn' && <span className="ml-2 text-[10px] uppercase font-bold text-white/40 glass px-2 py-0.5 rounded-full">Withdrawn</span>}
                                                            </div>
                                                        </div>
                                                        {isOrganizer && p.status === 'active' && (
                                                            <button onClick={() => id && withdrawParticipant(id, p.playerId)} className="text-muted hover:text-red transition-colors">
                                                                <UserMinus size={18} />
                                                            </button>
                                                        )}
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </Card>
                            </div>
                            <div>
                                {isOrganizer && activeTournament.status !== 'completed' && (
                                    <Card title="Add Player">
                                        <div className="flex flex-col gap-4">
                                            <Input
                                                placeholder="Player Name"
                                                value={newPlayerName}
                                                onChange={e => setNewPlayerName(e.target.value)}
                                                onKeyDown={e => e.key === 'Enter' && handleAddPlayer()}
                                            />
                                            <Button variant="primary" className="w-full" onClick={handleAddPlayer}>
                                                <Plus size={18} className="mr-2" /> Add Participant
                                            </Button>
                                        </div>
                                    </Card>
                                )}
                            </div>
                        </div>
                    )}

                    {activeTab === 'rounds' && (
                        <div className="flex flex-col gap-8">
                            {activeTournament.rounds.length === 0 ? (
                                <Card className="text-center py-12">
                                    <Play size={48} className="mx-auto mb-4 text-muted opacity-20" />
                                    <h3 className="text-xl mb-2">Tournament hasn't started</h3>
                                    <p className="text-secondary mb-6">Add participants and start the first round to begin.</p>
                                    {isOrganizer && (
                                        <Button onClick={() => id && generateRound(id)}>Generate Round 1</Button>
                                    )}
                                </Card>
                            ) : (
                                [...activeTournament.rounds].reverse().map(round => (
                                    <div key={round.number} className="flex flex-col gap-4">
                                        <div className="flex justify-between items-center px-2">
                                            <h3 className="text-2xl font-outfit">Round {round.number}</h3>
                                            <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase ${round.status === 'completed' ? 'bg-green/10 text-green' : 'bg-purple/10 text-purple'}`} style={{ color: round.status === 'completed' ? 'var(--color-green)' : 'var(--color-purple)' }}>
                                                {round.status === 'completed' ? <CheckCircle2 size={14} /> : null}
                                                {round.status}
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                            {round.tables.map((table, idx) => (
                                                <Card key={table.id} className="relative overflow-hidden group">
                                                    <div className="flex justify-between items-center mb-4 pb-2 border-b border-white/5">
                                                        <span className="text-xs font-bold text-muted uppercase tracking-tighter">Table {idx + 1}</span>
                                                        {table.status === 'completed' && <CheckCircle2 size={16} className="text-mana-green" />}
                                                    </div>
                                                    <div className="flex flex-col gap-3">
                                                        {table.playerIds.map(pid => {
                                                            const player = activeTournament.participants.find(p => p.playerId === pid);
                                                            const res = table.results.find(r => r.playerId === pid);
                                                            return (
                                                                <div key={pid} className="flex justify-between items-center gap-2">
                                                                    <span className="text-sm truncate font-medium">{player?.name || 'Unknown'}</span>
                                                                    {table.status === 'completed' && (
                                                                        <span className="px-2 py-0.5 glass rounded text-[10px] font-bold text-mana-gold">
                                                                            {res?.position}º • {res?.points} pts
                                                                        </span>
                                                                    )}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                    {isOrganizer && table.status === 'pending' && activeTournament.status !== 'completed' && (
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            className="mt-4 w-full border border-white/10 hover:border-purple/50 bg-white/5"
                                                            onClick={() => handleOpenResultModal(round.number, table)}
                                                        >
                                                            <Edit3 size={14} className="mr-2" /> Enter Results
                                                        </Button>
                                                    )}
                                                </Card>
                                            ))}
                                        </div>
                                    </div>
                                ))
                            )}
                            {isOrganizer && activeTournament.rounds.every(r => r.status === 'completed') && activeTournament.rounds.length > 0 && (
                                <Button variant="glow" onClick={() => id && generateRound(id)} className="self-center mt-4">
                                    Next Round <ChevronRight size={18} className="ml-2" />
                                </Button>
                            )}
                        </div>
                    )}

                    {activeTab === 'standings' && (
                        <div className="flex flex-col gap-8">
                            {activeTournament.status === 'completed' && (
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                    {[2, 1, 3].map((pos) => {
                                        const p = activeTournament.participants.find(p => p.rank === pos);
                                        if (!p) return null;
                                        return (
                                            <div key={pos} className={`p-6 glass rounded-2xl flex flex-col items-center gap-4 ${pos === 1 ? 'border-gold/30 bg-gold/5 order-1 md:order-2 scale-105' : 'border-white/10 order-2 md:order-1'}`} style={pos === 1 ? { borderColor: 'rgba(var(--color-gold-rgb), 0.3)' } : {}}>
                                                <div className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl ${pos === 1 ? 'bg-gold text-bg-dark' : 'bg-white/10'}`} style={pos === 1 ? { backgroundColor: 'var(--color-gold)' } : {}}>
                                                    {pos === 1 ? <Trophy /> : pos}
                                                </div>
                                                <div className="text-center">
                                                    <h4 className="text-xl font-outfit">{p.name}</h4>
                                                    <p className="text-secondary text-sm">{p.totalPoints} Points • {p.buchholz} BH</p>
                                                </div>
                                                <div className="px-4 py-1 rounded-full bg-white/5 text-[10px] font-bold uppercase tracking-widest">
                                                    {pos === 1 ? 'Tournament Champion' : `${pos}º Place`}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                            <Card title={activeTournament.status === 'completed' ? "Final Standings" : "Current Standings"}>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left border-collapse">
                                        <thead>
                                            <tr className="text-muted text-xs uppercase font-bold border-b border-white/5">
                                                <th className="pb-4 px-2">Rank</th>
                                                <th className="pb-4 px-2">Player</th>
                                                <th className="pb-4 px-2">Points</th>
                                                <th className="pb-4 px-2">BH</th>
                                                <th className="pb-4 px-2 text-right">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {activeTournament.participants.map((p, idx) => (
                                                <tr key={p.playerId} className="border-b border-white/5 hover:bg-white/2 transition-colors">
                                                    <td className="py-4 px-2">
                                                        {idx + 1 === 1 && <Trophy size={14} className="inline mr-2 text-gold" style={{ color: 'var(--color-gold)' }} />}
                                                        {idx + 1}
                                                    </td>
                                                    <td className="py-4 px-2 font-medium">{p.name}</td>
                                                    <td className="py-4 px-2 font-bold text-primary">{p.totalPoints}</td>
                                                    <td className="py-4 px-2 text-secondary text-sm">{p.buchholz || 0}</td>
                                                    <td className="py-4 px-2 text-right">
                                                        <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${p.status === 'active' ? 'bg-green/10 text-green' : 'bg-red/10 text-red'}`} style={{ color: p.status === 'active' ? 'var(--color-green)' : 'var(--color-red)' }}>
                                                            {p.status}
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </Card>
                        </div>
                    )}

                    {activeTab === 'settings' && (
                        <div className="max-w-xl">
                            <Card title="Tournament Configuration">
                                <div className="flex flex-col gap-6">
                                    <p className="text-secondary text-sm">Basic configuration for this tournament.</p>
                                    {/* In a real app, these would be editable inputs */}
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="p-4 glass rounded-xl">
                                            <span className="text-xs text-muted">Format</span>
                                            <p className="font-bold">{activeTournament.format}</p>
                                        </div>
                                        <div className="p-4 glass rounded-xl">
                                            <span className="text-xs text-muted">Status</span>
                                            <p className="font-bold uppercase text-purple" style={{ color: 'var(--color-purple)' }}>{activeTournament.status}</p>
                                        </div>
                                    </div>
                                    <Button variant="danger" className="w-full mt-4">Cancel Tournament</Button>
                                </div>
                            </Card>
                        </div>
                    )}
                </div>
            </div>

            {/* Result Entry Modal */}
            <Modal
                isOpen={!!selectedTable}
                onClose={() => setSelectedTable(null)}
                title={`Table Results - Round ${selectedTable?.round}`}
                footer={
                    <div className="flex gap-4 justify-end">
                        <Button variant="secondary" onClick={() => setSelectedTable(null)}>Cancel</Button>
                        <Button variant="glow" onClick={handleSubmitTableResults}>Apply Results</Button>
                    </div>
                }
            >
                <div className="flex flex-col gap-6">
                    <p className="text-secondary text-sm">Assign finishing positions for all players at this table.</p>
                    <div className="flex flex-col gap-3">
                        {selectedTable?.table.playerIds.map((pid: string) => {
                            const player = activeTournament.participants.find(p => p.playerId === pid);
                            return (
                                <div key={pid} className="flex justify-between items-center p-4 glass rounded-2xl bg-white/2 border-white/5">
                                    <span className="font-bold text-primary">{player?.name}</span>
                                    <div className="flex items-center gap-3">
                                        <span className="text-[10px] uppercase font-bold text-muted">Result</span>
                                        <select
                                            className="bg-bg-dark border border-white/10 rounded-lg px-3 py-2 outline-none focus:border-purple/50 transition-all font-bold text-gold"
                                            style={{ color: 'var(--color-gold)' }}
                                            value={tempResults[pid] || 1}
                                            onChange={(e) => setTempResults(prev => ({ ...prev, [pid]: parseInt(e.target.value) }))}
                                        >
                                            {activeTournament.format === 'multiplayer' ? (
                                                <>
                                                    <option value="1">🏆 Champion (Winner)</option>
                                                    <option value="1">🛡️ Survivor (Tied 1st)</option>
                                                    <option value="2">💀 Eliminated 1 (2º)</option>
                                                    <option value="3">💀 Eliminated 2 (3º)</option>
                                                    <option value="4">💀 Eliminated 3 (4º)</option>
                                                </>
                                            ) : (
                                                <>
                                                    <option value="1">Winner</option>
                                                    <option value="2">Loser</option>
                                                    <option value="0">Draw</option>
                                                </>
                                            )}
                                        </select>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </Modal>

            <style>{`
        .bg-glass { background: rgba(255, 255, 255, 0.03); }
        .text-purple { color: var(--color-purple); }
        .text-gold { color: var(--color-gold); }
        .text-green { color: var(--color-green); }
        .text-red { color: var(--color-red); }
        .text-mana-green { color: var(--color-green); } /* Using existing green for mana-green */
        .text-mana-gold { color: var(--color-gold); } /* Using existing gold for mana-gold */
      `}</style>
        </PageShell>
    );
};

export default TournamentDashboard;
