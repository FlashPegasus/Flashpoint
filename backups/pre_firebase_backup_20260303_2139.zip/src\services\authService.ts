import type { User } from '../types';
import { storage } from '../utils/storage';
import { v4 as uuidv4 } from 'uuid';

const STORAGE_KEY = 'current_user';

export const authService = {
    getCurrentUser: (): User | null => {
        return storage.get<User | null>(STORAGE_KEY, null);
    },

    login: async (email: string): Promise<User> => {
        // Mock login logic
        const existingUsers = storage.get<User[]>('users', []);
        let user = existingUsers.find(u => u.email === email);

        if (!user) {
            // Auto-register if not found (simulating easy onboarding)
            user = {
                id: uuidv4(),
                name: email.split('@')[0],
                email,
                role: 'organizer', // Default to organizer for testing
                stats: {
                    tournamentsPlayed: 0,
                    wins: 0,
                    draws: 0,
                    losses: 0,
                    leaguesJoined: 0,
                    accumulatedPoints: 0
                }
            };
            existingUsers.push(user);
            storage.set('users', existingUsers);
        }

        storage.set(STORAGE_KEY, user);
        return user;
    },

    logout: (): void => {
        storage.remove(STORAGE_KEY);
    },

    updateProfile: (updatedUser: Partial<User>): User => {
        const currentUser = authService.getCurrentUser();
        if (!currentUser) throw new Error('Not authenticated');

        const newUser = { ...currentUser, ...updatedUser };
        storage.set(STORAGE_KEY, newUser);

        // Update in global users list too
        const users = storage.get<User[]>('users', []);
        const index = users.findIndex(u => u.id === newUser.id);
        if (index !== -1) {
            users[index] = newUser;
            storage.set('users', users);
        }

        return newUser;
    }
};
