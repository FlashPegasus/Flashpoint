import type { Tournament, Participant, Round, Table, TableResult } from '../types';
import { storage } from '../utils/storage';
import { v4 as uuidv4 } from 'uuid';
import { generateSwissPairings } from '../engine/swiss';
import { generateMultiplayerTables } from '../engine/multiplayer';

const STORAGE_KEY = 'tournaments';

export const tournamentService = {
    getTournaments: (): Tournament[] => {
        return storage.get<Tournament[]>(STORAGE_KEY, []);
    },

    getTournamentById: (id: string): Tournament | undefined => {
        return tournamentService.getTournaments().find(t => t.id === id);
    },

    saveTournament: (tournament: Tournament): void => {
        const tournaments = tournamentService.getTournaments();
        const index = tournaments.findIndex(t => t.id === tournament.id);
        if (index !== -1) {
            tournaments[index] = tournament;
        } else {
            tournaments.push(tournament);
        }
        storage.set(STORAGE_KEY, tournaments);
    },

    createTournament: (data: Partial<Tournament>): Tournament => {
        const tournament: Tournament = {
            id: uuidv4(),
            name: data.name || 'Untitled Tournament',
            date: data.date || new Date().toISOString(),
            location: data.location || 'Online',
            description: data.description || '',
            format: data.format || '1v1',
            pairingMode: data.pairingMode || 'standard',
            status: 'registration',
            organizerId: data.organizerId || 'mock-id',
            minPlayersPerTable: data.minPlayersPerTable || 2,
            maxPlayersPerTable: data.maxPlayersPerTable || 2,
            exactTableSize: data.exactTableSize,
            scoring: data.scoring || { type: 'standard', pointsPerWin: 3, pointsPerDraw: 1, pointsPerLoss: 0 },
            allowLateRegistration: data.allowLateRegistration ?? true,
            allowWithdrawal: data.allowWithdrawal ?? true,
            maxParticipants: data.maxParticipants,
            participants: [],
            rounds: [],
            ...data
        };

        tournamentService.saveTournament(tournament);
        return tournament;
    },

    addParticipant: (tournamentId: string, player: Partial<Participant>): Participant => {
        const tournament = tournamentService.getTournamentById(tournamentId);
        if (!tournament) throw new Error('Tournament not found');

        const participant: Participant = {
            playerId: player.playerId || uuidv4(),
            name: player.name || 'New Player',
            status: 'active',
            joinedRound: tournament.rounds.length + 1,
            totalPoints: 0,
            previousOpponents: [],
            ...player
        };

        tournament.participants.push(participant);
        tournamentService.saveTournament(tournament);
        return participant;
    },

    withdrawParticipant: (tournamentId: string, playerId: string): void => {
        const tournament = tournamentService.getTournamentById(tournamentId);
        if (!tournament) throw new Error('Tournament not found');

        const participant = tournament.participants.find(p => p.playerId === playerId);
        if (participant) {
            participant.status = 'withdrawn';
            tournamentService.saveTournament(tournament);
        }
    },

    generateNextRound: (tournamentId: string): Round => {
        const tournament = tournamentService.getTournamentById(tournamentId);
        if (!tournament) throw new Error('Tournament not found');

        const roundNumber = tournament.rounds.length + 1;
        let tables: Table[] = [];

        if (tournament.format === '1v1') {
            tables = generateSwissPairings(tournament.participants, tournament.rounds, {
                pairingMode: tournament.pairingMode
            });
        } else {
            tables = generateMultiplayerTables(tournament.participants, {
                minPerTable: tournament.minPlayersPerTable,
                maxPerTable: tournament.maxPlayersPerTable,
                exactSize: tournament.exactTableSize
            });
        }

        const newRound: Round = {
            number: roundNumber,
            tables,
            status: 'pending'
        };

        tournament.rounds.push(newRound);
        tournament.status = 'ongoing';
        tournamentService.saveTournament(tournament);
        return newRound;
    },

    recordTableResult: (tournamentId: string, roundNumber: number, tableId: string, results: TableResult[]): void => {
        const tournament = tournamentService.getTournamentById(tournamentId);
        if (!tournament) throw new Error('Tournament not found');

        const round = tournament.rounds.find(r => r.number === roundNumber);
        if (!round) throw new Error('Round not found');

        const table = round.tables.find(t => t.id === tableId);
        if (!table) throw new Error('Table not found');

        table.results = results;
        table.status = 'completed';

        // Check if round is finished
        if (round.tables.every(t => t.status === 'completed')) {
            round.status = 'completed';

            // Update participant history and points
            round.tables.forEach(t => {
                // Shared Points Logic:
                // Count how many players at each position
                const posCounts: Record<number, number> = {};
                t.results.forEach(r => {
                    posCounts[r.position] = (posCounts[r.position] || 0) + 1;
                });

                // Calculate Shared Points
                const sharedPoints: Record<number, number> = {};
                const sortedUniquePositions = Object.keys(posCounts).map(Number).sort((a, b) => a - b);

                let currentPosIdx = 1;
                sortedUniquePositions.forEach(pos => {
                    const count = posCounts[pos];
                    let totalPosPoints = 0;

                    for (let i = 0; i < count; i++) {
                        const rank = currentPosIdx + i;
                        totalPosPoints += tournament.scoring.positions?.[t.playerIds.length]?.[rank] || 0;
                    }

                    sharedPoints[pos] = totalPosPoints / count;
                    currentPosIdx += count;
                });

                t.playerIds.forEach(pid => {
                    const participant = tournament.participants.find(p => p.playerId === pid);
                    if (participant) {
                        const opponents = t.playerIds.filter(id => id !== pid);
                        participant.previousOpponents = [
                            ...(participant.previousOpponents || []),
                            ...opponents
                        ];

                        const res = t.results.find(r => r.playerId === pid);
                        if (res) {
                            const pts = tournament.format === 'multiplayer'
                                ? sharedPoints[res.position]
                                : res.points;
                            participant.totalPoints += pts;
                        }
                    }
                });
            });

            // Calculate Tie-breakers (Buchholz)
            tournament.participants.forEach(p => {
                let buchholz = 0;
                p.previousOpponents?.forEach(oppId => {
                    const opponent = tournament.participants.find(opp => opp.playerId === oppId);
                    if (opponent) buchholz += opponent.totalPoints;
                });
                p.buchholz = buchholz;
            });

            // Update rankings
            tournament.participants.sort((a, b) => {
                if (b.totalPoints !== a.totalPoints) return b.totalPoints - a.totalPoints;
                return (b.buchholz || 0) - (a.buchholz || 0);
            });

            tournament.participants.forEach((p, idx) => {
                p.rank = idx + 1;
            });
        }

        tournamentService.saveTournament(tournament);
    },

    completeTournament: (tournamentId: string): void => {
        const tournament = tournamentService.getTournamentById(tournamentId);
        if (!tournament) throw new Error('Tournament not found');

        tournament.status = 'completed';
        tournamentService.saveTournament(tournament);
    },

    getUserStats: (userId: string) => {
        const tournaments = tournamentService.getTournaments();
        const participation = tournaments.filter(t =>
            t.participants.some(p => p.playerId === userId)
        );

        const stats = {
            totalTournaments: participation.length,
            tournamentsAsOrganizer: tournaments.filter(t => t.organizerId === userId).length,
            wins: 0,
            top3: 0,
            totalPoints: 0,
            recentTournaments: participation
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .slice(0, 5)
                .map(t => {
                    const p = t.participants.find(part => part.playerId === userId);
                    return {
                        id: t.id,
                        name: t.name,
                        date: t.date,
                        rank: p?.rank,
                        points: p?.totalPoints,
                        status: t.status
                    };
                })
        };

        participation.forEach(t => {
            const p = t.participants.find(part => part.playerId === userId);
            if (p) {
                if (p.rank === 1) stats.wins++;
                if (p.rank && p.rank <= 3) stats.top3++;
                stats.totalPoints += p.totalPoints;
            }
        });

        return stats;
    }
};
