import { create } from 'zustand';
import type { Tournament, Participant, TableResult } from '../types';
import { tournamentService } from '../services/tournamentService';

interface TournamentState {
    tournaments: Tournament[];
    activeTournament: Tournament | null;
    isLoading: boolean;

    loadTournaments: () => void;
    loadTournament: (id: string) => void;
    createTournament: (data: Partial<Tournament>) => Tournament;
    addParticipant: (tournamentId: string, player: Partial<Participant>) => void;
    withdrawParticipant: (tournamentId: string, playerId: string) => void;
    generateRound: (tournamentId: string) => void;
    submitResult: (tournamentId: string, roundNumber: number, tableId: string, results: TableResult[]) => void;
    completeTournament: (tournamentId: string) => void;
}

export const useTournamentStore = create<TournamentState>((set, get) => ({
    tournaments: [],
    activeTournament: null,
    isLoading: false,

    loadTournaments: () => {
        const tournaments = tournamentService.getTournaments();
        set({ tournaments });
    },

    loadTournament: (id: string) => {
        const tournament = tournamentService.getTournamentById(id);
        set({ activeTournament: tournament || null });
    },

    createTournament: (data) => {
        const t = tournamentService.createTournament(data);
        get().loadTournaments();
        return t;
    },

    addParticipant: (id, player) => {
        tournamentService.addParticipant(id, player);
        get().loadTournament(id);
        get().loadTournaments();
    },

    withdrawParticipant: (id, playerId) => {
        tournamentService.withdrawParticipant(id, playerId);
        get().loadTournament(id);
    },

    generateRound: (id) => {
        tournamentService.generateNextRound(id);
        get().loadTournament(id);
    },

    submitResult: (id, roundNum, tableId, results) => {
        tournamentService.recordTableResult(id, roundNum, tableId, results);
        get().loadTournament(id);
    },

    completeTournament: (id) => {
        tournamentService.completeTournament(id);
        get().loadTournament(id);
        get().loadTournaments();
    }
}));
